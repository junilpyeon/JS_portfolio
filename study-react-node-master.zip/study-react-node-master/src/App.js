import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="lightpink-background">
      <img src={logo} lat="logo"/>
      <h2>Let's develop!</h2>
    </div>
  );
}

export default App;
